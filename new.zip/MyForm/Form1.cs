﻿using System.Text.RegularExpressions;

namespace MyForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private string CheckPassword(string password)
        {
            // Проверка на пустой пароль
            if (string.IsNullOrEmpty(password))
            {
                return "Результат: ❌ Пароль не может быть пустым";
            }

            // Получение минимальной длины
            if (!int.TryParse(textBoxLength.Text, out int minLength) || minLength <= 0)
            {
                return "Результат: ❌ Некорректная длина пароля";
            }

            List<string> errors = new List<string>();

            // Проверка длины
            if (password.Length < minLength)
            {
                errors.Add($"длина меньше {minLength} символов");
            }

            // Проверка латиницы
            if (checkBoxLatin.Checked && !Regex.IsMatch(password, "[a-zA-Z]"))
            {
                errors.Add("нет латиницы");
            }

            // Проверка кириллицы
            if (checkBoxCyrillic.Checked)
            {
                bool hasCyrillic = Regex.IsMatch(password, "[а-яА-ЯёЁ]");
                if (!hasCyrillic)
                {
                    errors.Add("нет кириллицы");
                }
            }

            // Проверка спецсимволов
            if (checkBoxSpecial.Checked)
            {
                // Регулярное выражение для поиска спецсимволов
                // Спецсимволы: ! @ # $ % ^ & * ( ) - _ = + [ ] { } ; : ' " , . < > / ? \ |
                bool hasSpecialChars = Regex.IsMatch(password, @"[!@#$%^&*()\-_=+\[\]{};:'"",.<>/?\\|]");

                if (!hasSpecialChars)
                {
                    errors.Add("нет спецсимволов (!@#$%^&* и т.д.)");
                }
            }

            // Проверка цифр
            if (checkBoxNumber.Checked && !Regex.IsMatch(password, "[0-9]"))
            {
                errors.Add("нет цифр");
            }

            // Проверка строчных букв
            if (checkBoxLowerCase.Checked)
            {
                bool hasLowercase = false;
                if (checkBoxLatin.Checked)
                    hasLowercase |= Regex.IsMatch(password, "[a-z]");
                if (checkBoxCyrillic.Checked)
                    hasLowercase |= Regex.IsMatch(password, "[а-яё]");

                if (!hasLowercase)
                {
                    errors.Add("нет строчных букв");
                }
            }

            // Проверка заглавных букв
            if (checkBoxUpperCase.Checked)
            {
                bool hasUppercase = false;
                if (checkBoxLatin.Checked)
                    hasUppercase |= Regex.IsMatch(password, "[A-Z]");
                if (checkBoxCyrillic.Checked)
                    hasUppercase |= Regex.IsMatch(password, "[А-ЯЁ]");

                if (!hasUppercase)
                {
                    errors.Add("нет заглавных букв");
                }
            }

            // Проверка на повторения
            if (checkBoxNoRepeat.Checked)
            {
                var uniqueChars = new HashSet<char>(password);
                if (uniqueChars.Count != password.Length)
                {
                    errors.Add("есть повторяющиеся символы");
                }
            }

            // Формирование результата
            if (errors.Count == 0)
            {
                return "Результат: V Пароль соответствует требованиям";
            }
            else
            {
                return $"Результат: ❌ Пароль не соответствует требованиям:\n- {string.Join("\n- ", errors)}";
            }
        }
        private void buttonCheckPassword_Click(object sender, EventArgs e)
        {
            writeResult(CheckPassword(textBoxCheckPassword.Text));
        }
        private void writeResult(string message)
        {
            labelResult.Text = message;
        }
        private void buttonGeneratePassword_Click(object sender, EventArgs e)
        {
            try
            {
                // Получение минимальной длины
                if (!int.TryParse(textBoxLength.Text, out int passwordLength) || passwordLength <= 0)
                {
                    MessageBox.Show("Некорректная длина пароля", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Проверка, что выбрана хотя бы одна категория символов
                if (!checkBoxLatin.Checked && !checkBoxCyrillic.Checked && !checkBoxNumber.Checked &&
                    !checkBoxSpecial.Checked)
                {
                    // Проверяем также через регистры
                    if (!checkBoxLowerCase.Checked && !checkBoxUpperCase.Checked)
                    {
                        MessageBox.Show("Выберите хотя бы одну категорию символов для генерации пароля",
                            "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                string password = GeneratePassword(passwordLength);

                // Предположим, у вас есть textBoxPassword для ввода пароля
                textBoxGeneratedPass.Text = password;

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при генерации пароля: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private int GetMinRequiredLength()
        {
            int min = 0;

            // 1. Считаем основные категории (Языки)
            int languageCount = 0;
            if (checkBoxLatin.Checked) languageCount++;
            if (checkBoxCyrillic.Checked) languageCount++;

            min += languageCount;

            // 2. Считаем дополнительные категории
            if (checkBoxNumber.Checked) min++;
            if (checkBoxSpecial.Checked) min++;

            // 3. Логика регистров
            // Если выбрано ОБА регистра, но язык только ОДИН, 
            // нам не хватает одного символа, чтобы показать и строчную, и заглавную.
            if (checkBoxLowerCase.Checked && checkBoxUpperCase.Checked && languageCount == 1)
            {
                min++;
            }
            // Если языка два, то в два символа влезут и два языка, и два регистра (Aя).
            // Если языков ноль (только цифры), то регистры вообще не добавляют длину.

            return min == 0 && (checkBoxLatin.Checked || checkBoxCyrillic.Checked) ? 1 : min;
        }
        private string GeneratePassword(int length)
        {
            int minLength = GetMinRequiredLength();
            if (length < minLength)
            {
                MessageBox.Show($"Минимальная длина для ваших настроек: {minLength}");
                return string.Empty;
            }

            Random random = new Random();
            List<char> passwordChars = new List<char>();

            string latLow = "abcdefghijklmnopqrstuvwxyz";
            string latUp = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string cyrLow = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя";
            string cyrUp = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ";
            string nums = "0123456789";
            string specs = "!@#$%^&*()-_=+[]{};:'\",.<>/?\\|";

            // 1. Логика регистров
            bool lowSelected = checkBoxLowerCase.Checked;
            bool upSelected = checkBoxUpperCase.Checked;
            bool anyReg = !lowSelected && !upSelected; // Ни один регистр не выбран явно

            bool canUseLow = lowSelected || anyReg;
            bool canUseUp = upSelected || anyReg;

            // 2. РАСЧЕТ МИНИМАЛЬНОЙ ДЛИНЫ (ИСПРАВЛЕНО)
            int minRequiredLength = 0;

            // Если регистры выбраны явно (нажаты галочки), считаем их как отдельные обязательные символы
            if (lowSelected && (checkBoxLatin.Checked || checkBoxCyrillic.Checked)) minRequiredLength++;
            if (upSelected && (checkBoxLatin.Checked || checkBoxCyrillic.Checked)) minRequiredLength++;

            // Если регистры НЕ выбраны, но выбран язык — нам нужна хотя бы 1 любая буква
            if (anyReg && (checkBoxLatin.Checked || checkBoxCyrillic.Checked)) minRequiredLength++;

            if (checkBoxNumber.Checked) minRequiredLength++;
            if (checkBoxSpecial.Checked) minRequiredLength++;

            // --- ПРОВЕРКА ДЛИНЫ ---
            if (length < minRequiredLength)
            {
                MessageBox.Show($"Выбранная длина ({length}) слишком мала.\n" +
                                $"Для выбранных настроек минимальная длина: {minRequiredLength}.",
                                "Ошибка длины", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return string.Empty;
            }

            // 3. ФОРМИРУЕМ ПУЛ ВСЕХ СИМВОЛОВ
            string allPossible = "";
            if (checkBoxLatin.Checked)
            {
                if (canUseLow) allPossible += latLow;
                if (canUseUp) allPossible += latUp;
            }
            if (checkBoxCyrillic.Checked)
            {
                if (canUseLow) allPossible += cyrLow;
                if (canUseUp) allPossible += cyrUp;
            }
            if (checkBoxNumber.Checked) allPossible += nums;
            if (checkBoxSpecial.Checked) allPossible += specs;

            if (string.IsNullOrEmpty(allPossible)) return string.Empty;

            if (checkBoxNoRepeat.Checked && length > allPossible.Distinct().Count())
            {
                MessageBox.Show("Недостаточно уникальных символов.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return string.Empty;
            }

            // 4. ГАРАНТИРОВАННЫЙ МИНИМУМ
            bool lastWasCyr = false;
            bool lastWasLat = false;

            // Обязательная строчная (только если чекбокс нажат ИЛИ если это единственный шанс добавить букву)
            if (canUseLow && (checkBoxLatin.Checked || checkBoxCyrillic.Checked) && passwordChars.Count < length)
            {
                // Если выбран только верхний регистр, пропускаем этот шаг
                if (!upSelected || lowSelected || anyReg)
                {
                    bool useCyr = (checkBoxLatin.Checked && checkBoxCyrillic.Checked) ? random.Next(2) == 0 : checkBoxCyrillic.Checked;
                    string pool = useCyr ? cyrLow : latLow;
                    lastWasCyr = useCyr; lastWasLat = !useCyr;
                    passwordChars.Add(pool[random.Next(pool.Length)]);
                }
            }

            // Обязательная заглавная (только если чекбокс нажат ИЛИ если еще есть место)
            if (canUseUp && (checkBoxLatin.Checked || checkBoxCyrillic.Checked) && passwordChars.Count < length)
            {
                // Добавляем, если либо явно просили заглавные, либо еще не добавили ни одной буквы
                if (upSelected || passwordChars.Count == 0 || (anyReg && passwordChars.Count < minRequiredLength - (checkBoxNumber.Checked ? 1 : 0) - (checkBoxSpecial.Checked ? 1 : 0)))
                {
                    string pool = "";
                    if (lastWasCyr && checkBoxLatin.Checked) pool = latUp;
                    else if (lastWasLat && checkBoxCyrillic.Checked) pool = cyrUp;
                    else pool = (checkBoxLatin.Checked ? latUp : "") + (checkBoxCyrillic.Checked ? cyrUp : "");

                    if (!string.IsNullOrEmpty(pool)) passwordChars.Add(pool[random.Next(pool.Length)]);
                }
            }

            if (checkBoxNumber.Checked && passwordChars.Count < length)
                passwordChars.Add(nums[random.Next(nums.Length)]);

            if (checkBoxSpecial.Checked && passwordChars.Count < length)
                passwordChars.Add(specs[random.Next(specs.Length)]);

            // 5. ДОБОР
            while (passwordChars.Count < length)
            {
                char nextChar = allPossible[random.Next(allPossible.Length)];
                if (checkBoxNoRepeat.Checked) { if (!passwordChars.Contains(nextChar)) passwordChars.Add(nextChar); }
                else passwordChars.Add(nextChar);
            }

            return new string(passwordChars.OrderBy(x => random.Next()).ToArray());
        }
    }
}
