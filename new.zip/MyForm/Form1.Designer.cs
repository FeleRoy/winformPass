﻿namespace MyForm
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            checkBoxLatin = new CheckBox();
            checkBoxCyrillic = new CheckBox();
            checkBoxNumber = new CheckBox();
            checkBoxLowerCase = new CheckBox();
            checkBoxUpperCase = new CheckBox();
            checkBoxNoRepeat = new CheckBox();
            textBoxLength = new TextBox();
            textBoxCheckPassword = new TextBox();
            labelLengthPassword = new Label();
            labelCheckPassword = new Label();
            textBoxGeneratedPass = new TextBox();
            label1 = new Label();
            buttonGeneratePassword = new Button();
            buttonCheckPassword = new Button();
            labelResult = new Label();
            checkBoxSpecial = new CheckBox();
            SuspendLayout();
            // 
            // checkBoxLatin
            // 
            checkBoxLatin.AutoSize = true;
            checkBoxLatin.Location = new Point(17, 23);
            checkBoxLatin.Name = "checkBoxLatin";
            checkBoxLatin.Size = new Size(79, 19);
            checkBoxLatin.TabIndex = 0;
            checkBoxLatin.Text = "Латиница";
            checkBoxLatin.UseVisualStyleBackColor = true;
            // 
            // checkBoxCyrillic
            // 
            checkBoxCyrillic.AutoSize = true;
            checkBoxCyrillic.Location = new Point(17, 48);
            checkBoxCyrillic.Name = "checkBoxCyrillic";
            checkBoxCyrillic.Size = new Size(88, 19);
            checkBoxCyrillic.TabIndex = 1;
            checkBoxCyrillic.Text = "Кириллица";
            checkBoxCyrillic.TextImageRelation = TextImageRelation.ImageBeforeText;
            checkBoxCyrillic.UseVisualStyleBackColor = true;
            // 
            // checkBoxNumber
            // 
            checkBoxNumber.AutoSize = true;
            checkBoxNumber.Location = new Point(17, 98);
            checkBoxNumber.Name = "checkBoxNumber";
            checkBoxNumber.Size = new Size(67, 19);
            checkBoxNumber.TabIndex = 2;
            checkBoxNumber.Text = "Цифры";
            checkBoxNumber.TextImageRelation = TextImageRelation.ImageBeforeText;
            checkBoxNumber.UseVisualStyleBackColor = true;
            // 
            // checkBoxLowerCase
            // 
            checkBoxLowerCase.AutoSize = true;
            checkBoxLowerCase.Location = new Point(17, 123);
            checkBoxLowerCase.Name = "checkBoxLowerCase";
            checkBoxLowerCase.Size = new Size(82, 19);
            checkBoxLowerCase.TabIndex = 3;
            checkBoxLowerCase.Text = "Строчные";
            checkBoxLowerCase.TextImageRelation = TextImageRelation.ImageBeforeText;
            checkBoxLowerCase.UseVisualStyleBackColor = true;
            // 
            // checkBoxUpperCase
            // 
            checkBoxUpperCase.AutoSize = true;
            checkBoxUpperCase.Location = new Point(17, 148);
            checkBoxUpperCase.Name = "checkBoxUpperCase";
            checkBoxUpperCase.Size = new Size(85, 19);
            checkBoxUpperCase.TabIndex = 4;
            checkBoxUpperCase.Text = "Заглавные";
            checkBoxUpperCase.TextImageRelation = TextImageRelation.ImageBeforeText;
            checkBoxUpperCase.UseVisualStyleBackColor = true;
            // 
            // checkBoxNoRepeat
            // 
            checkBoxNoRepeat.AutoSize = true;
            checkBoxNoRepeat.Location = new Point(17, 173);
            checkBoxNoRepeat.Name = "checkBoxNoRepeat";
            checkBoxNoRepeat.Size = new Size(113, 19);
            checkBoxNoRepeat.TabIndex = 5;
            checkBoxNoRepeat.Text = "Без повторений";
            checkBoxNoRepeat.TextImageRelation = TextImageRelation.ImageBeforeText;
            checkBoxNoRepeat.UseVisualStyleBackColor = true;
            // 
            // textBoxLength
            // 
            textBoxLength.Location = new Point(18, 217);
            textBoxLength.Name = "textBoxLength";
            textBoxLength.Size = new Size(100, 23);
            textBoxLength.TabIndex = 6;
            textBoxLength.Text = "8";
            // 
            // textBoxCheckPassword
            // 
            textBoxCheckPassword.Location = new Point(18, 260);
            textBoxCheckPassword.Name = "textBoxCheckPassword";
            textBoxCheckPassword.Size = new Size(245, 23);
            textBoxCheckPassword.TabIndex = 7;
            // 
            // labelLengthPassword
            // 
            labelLengthPassword.AutoSize = true;
            labelLengthPassword.Location = new Point(151, 220);
            labelLengthPassword.Name = "labelLengthPassword";
            labelLengthPassword.Size = new Size(213, 15);
            labelLengthPassword.TabIndex = 8;
            labelLengthPassword.Text = "Задайте минимальную длину пароля";
            // 
            // labelCheckPassword
            // 
            labelCheckPassword.AutoSize = true;
            labelCheckPassword.Location = new Point(273, 263);
            labelCheckPassword.Name = "labelCheckPassword";
            labelCheckPassword.Size = new Size(171, 15);
            labelCheckPassword.TabIndex = 9;
            labelCheckPassword.Text = "Введите пароль для проверки";
            // 
            // textBoxGeneratedPass
            // 
            textBoxGeneratedPass.Location = new Point(18, 316);
            textBoxGeneratedPass.Name = "textBoxGeneratedPass";
            textBoxGeneratedPass.Size = new Size(621, 23);
            textBoxGeneratedPass.TabIndex = 10;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(645, 319);
            label1.Name = "label1";
            label1.Size = new Size(152, 15);
            label1.TabIndex = 11;
            label1.Text = "Пароль сгенерированный";
            // 
            // buttonGeneratePassword
            // 
            buttonGeneratePassword.Location = new Point(81, 370);
            buttonGeneratePassword.Name = "buttonGeneratePassword";
            buttonGeneratePassword.Size = new Size(181, 23);
            buttonGeneratePassword.TabIndex = 12;
            buttonGeneratePassword.Text = "Сгенерировать пароль";
            buttonGeneratePassword.UseVisualStyleBackColor = true;
            buttonGeneratePassword.Click += buttonGeneratePassword_Click;
            // 
            // buttonCheckPassword
            // 
            buttonCheckPassword.Location = new Point(427, 369);
            buttonCheckPassword.Name = "buttonCheckPassword";
            buttonCheckPassword.Size = new Size(198, 23);
            buttonCheckPassword.TabIndex = 13;
            buttonCheckPassword.Text = "Проверить пароль";
            buttonCheckPassword.UseVisualStyleBackColor = true;
            buttonCheckPassword.Click += buttonCheckPassword_Click;
            // 
            // labelResult
            // 
            labelResult.AutoSize = true;
            labelResult.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            labelResult.Location = new Point(453, 9);
            labelResult.Name = "labelResult";
            labelResult.Size = new Size(62, 15);
            labelResult.TabIndex = 14;
            labelResult.Text = "Результат";
            // 
            // checkBoxSpecial
            // 
            checkBoxSpecial.AutoSize = true;
            checkBoxSpecial.Location = new Point(17, 73);
            checkBoxSpecial.Name = "checkBoxSpecial";
            checkBoxSpecial.Size = new Size(105, 19);
            checkBoxSpecial.TabIndex = 15;
            checkBoxSpecial.Text = "Спецсимволы";
            checkBoxSpecial.TextImageRelation = TextImageRelation.ImageBeforeText;
            checkBoxSpecial.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(checkBoxSpecial);
            Controls.Add(labelResult);
            Controls.Add(buttonCheckPassword);
            Controls.Add(buttonGeneratePassword);
            Controls.Add(label1);
            Controls.Add(textBoxGeneratedPass);
            Controls.Add(labelCheckPassword);
            Controls.Add(labelLengthPassword);
            Controls.Add(textBoxCheckPassword);
            Controls.Add(textBoxLength);
            Controls.Add(checkBoxNoRepeat);
            Controls.Add(checkBoxUpperCase);
            Controls.Add(checkBoxLowerCase);
            Controls.Add(checkBoxNumber);
            Controls.Add(checkBoxCyrillic);
            Controls.Add(checkBoxLatin);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CheckBox checkBoxLatin;
        private CheckBox checkBoxCyrillic;
        private CheckBox checkBoxNumber;
        private CheckBox checkBoxLowerCase;
        private CheckBox checkBoxUpperCase;
        private CheckBox checkBoxNoRepeat;
        private TextBox textBoxLength;
        private TextBox textBoxCheckPassword;
        private Label labelLengthPassword;
        private Label labelCheckPassword;
        private TextBox textBoxGeneratedPass;
        private Label label1;
        private Button buttonGeneratePassword;
        private Button buttonCheckPassword;
        private Label labelResult;
        private CheckBox checkBoxSpecial;
    }
}
